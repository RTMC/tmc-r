library(testthat)
library(tmcRtestrunner)

test_check("tmcRtestrunner")
