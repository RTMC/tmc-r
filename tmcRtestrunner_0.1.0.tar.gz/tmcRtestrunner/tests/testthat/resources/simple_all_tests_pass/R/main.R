RetTrue <- function() {
  return(TRUE)
}

RetOne <- function() {
  return(1)
}

Add <- function(a, b) {
  return(a + b)
}